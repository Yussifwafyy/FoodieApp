package com.example.foodieapp.pojo

data class MealList(
    val meals: List<Meal>
)