package com.example.foodieapp.pojo

data class MealsByCategoryList(
    val meals: List<MealsByCategory>
)