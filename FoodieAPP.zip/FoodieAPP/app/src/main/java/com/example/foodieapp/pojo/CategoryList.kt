package com.example.foodieapp.pojo

data class CategoryList(
    val categories: List<Category>
)